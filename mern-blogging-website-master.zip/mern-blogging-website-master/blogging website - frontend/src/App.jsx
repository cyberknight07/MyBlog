const App = () => {
    return (
        <h1>MERN Blogging website by modern web</h1>
    )
}

export default App;